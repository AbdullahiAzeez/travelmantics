package com.example.travelmantics;

public class Travel {
}
